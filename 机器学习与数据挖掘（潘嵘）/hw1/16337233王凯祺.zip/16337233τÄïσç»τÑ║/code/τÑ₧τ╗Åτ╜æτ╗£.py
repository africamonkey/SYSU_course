import random
import numpy as np
import tensorflow as tf
import pandas

BATCH_SIZE = 64


def get_train_value(train0, train1):
    data = np.zeros([BATCH_SIZE, num_cols])
    label = np.zeros([BATCH_SIZE, 2])
    for i in range(0, int(BATCH_SIZE / 2)):
        label[i][0] = 1
        label[i][1] = 0
        r = random.randint(0, len(train0) - 1)
        for j in range(0, num_cols):
            data[i][j] = train0[r].iloc[j]
    for i in range(int(BATCH_SIZE / 2), BATCH_SIZE):
        label[i][0] = 0
        label[i][1] = 1
        r = random.randint(0, len(train1) - 1)
        for j in range(0, num_cols):
            data[i][j] = train1[r].iloc[j]
    return data, label


def get_validate_value(train_data, train_label, x, y):
    data = train_data.iloc[x:y].values
    label = train_label.iloc[x:y].values
    data = np.delete(data, 0, axis=1)
    label = np.delete(label, 0, axis=1)
    label_ret = np.zeros([y - x, 2])
    for i in range(0, y - x):
        label_ret[i][0] = label_ret[i][1] = 0
        label_ret[i][label[i]] = 1
    return data, label_ret


def get_test_value(test_data):
    data = test_data.values
    data = np.delete(data, 0, axis=1)
    return data


if __name__ == '__main__':
#    train_data = pandas.read_csv('../train1.csv', header=None)
#    train_label = pandas.read_csv('../label.csv')
#    test_data = pandas.read_csv('../test1.csv', header=None)
    train_data = pandas.read_csv('../train2.csv', header=None)
    train_label = pandas.read_csv('../label.csv')
    test_data = pandas.read_csv('../test2.csv', header=None)
    num_rows = train_data.shape[0]
    num_cols = train_data.shape[1] - 1
    train_num = int(num_rows * 0.8)
    train0 = []
    train1 = []
    for i in range(0, train_num):
        x = train_data.iloc[i]
        x = x[1:]
        if train_label.iloc[i,1] == 0:
            train0.append(x)
        else:
            train1.append(x)

    with tf.Session() as sess:
        x = tf.placeholder(tf.dtypes.float32, [None, num_cols])
        W = tf.Variable(tf.random_uniform([num_cols, 2], -1.0, 1.0))
        b = tf.Variable(tf.random_uniform([2], -1.0, 1.0))
        y = tf.nn.softmax(tf.matmul(x, W) + b)
        y_ = tf.placeholder(tf.dtypes.float32, [None, 2])
        cross_entropy = tf.reduce_mean(-tf.reduce_sum(y_ * tf.log(y), reduction_indices=[1]))
        train_step = tf.train.GradientDescentOptimizer(0.01).minimize(cross_entropy)

        correct_prediction = tf.equal(tf.argmax(y, 1), tf.argmax(y_, 1))
        accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.dtypes.float32))

        test_step = tf.matmul(x, W) + b

        sess.run(tf.global_variables_initializer())

        validate_data, validate_label = get_validate_value(train_data, train_label, train_num, num_rows)
        for t in range(0, 5000):
            data, label = get_train_value(train0, train1)
            sess.run(train_step, {x: data, y_: label})
            result = sess.run(accuracy, {x:validate_data, y_: validate_label})
            print(t, ' ', result)

        data = get_test_value(test_data)
        result = sess.run(test_step, {x:data})
        for i in range(0, result.shape[0]):
            result[i][0] = min(result[i][0], 10)
            result[i][1] = min(result[i][1], 10)
            result[i][0] = np.exp(result[i][0])
            result[i][1] = np.exp(result[i][1])
            result[i][1] = result[i][1] / (result[i][0] + result[i][1])
            result[i][0] = i
        out = pandas.DataFrame(result, columns=['Id', 'label'])
        out['Id'] = out['Id'].astype(int)
        out.to_csv('./out.csv', encoding='utf-8', index=False)
