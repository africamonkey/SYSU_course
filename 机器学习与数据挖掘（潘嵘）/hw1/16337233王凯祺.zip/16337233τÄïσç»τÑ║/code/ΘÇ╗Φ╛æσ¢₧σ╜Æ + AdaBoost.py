import random
import numpy as np
import pandas

BATCH_SIZE = 64
learning_rate = 0.003


def calc_prob_sum(prob, prob_sum, train_num):
    prob_sum.clear()
    prob_sum.append(0)
    for i in range(0, train_num):
        prob_sum.append(prob_sum[i] + prob[i])


def get_train_value(train_data, train_label, train_num, prob_sum):
    data = train_data.iloc[0:1].values
    label = train_label.iloc[0:1].values
    for i in range(0, BATCH_SIZE):
        x = np.random.uniform(0.0, prob_sum[train_num])
        l = 0
        r = train_num - 1
        while l < r:
            mid = int((l + r + 1) / 2)
            if x >= prob_sum[mid]:
                l = mid
            else:
                r = mid - 1
        data1 = train_data.iloc[l:l+1].values
        label1 = train_label.iloc[l:l+1].values
        if i == 0:
            data = data1
            label = label1
        else:
            data = np.r_[data, data1]
            label = np.r_[label, label1]
    data = np.delete(data, 0, axis=1)
    label = np.delete(label, 0, axis=1)
    b = np.ones(BATCH_SIZE)
    data = np.c_[data, b]
    return data, label


def p1(X, W):
    t = np.matmul(W, X)
    if t > 10: t = 10
    e = np.exp(t)
    e = e / (1 + e)
    return e


def get_validate_value(train_data, train_label, x, y):
    data = train_data.iloc[x:y].values
    label = train_label.iloc[x:y].values
    data = np.delete(data, 0, axis=1)
    label = np.delete(label, 0, axis=1)
    b = np.ones(y - x)
    data = np.c_[data, b]
    return data, label


def get_test_value(test_data):
    data = test_data.values
    data = np.delete(data, 0, axis=1)
    b = np.ones(test_data.shape[0])
    data = np.c_[data, b]
    return data


def predict_and_output(validate_data, validate_label, validate0, validate1, W, f, t, ttt):
    predict = np.matmul(validate_data, W)
    for i in range(0, predict.shape[0]):
        if predict[i] > 10:
            predict[i] = 10
    epredict = np.exp(predict)
    predict = epredict / (1 + epredict)
    total = validate0 * validate1
    correct = 0
    s = []
    for i in range(0, validate_label.shape[0]):
        s.append((predict[i], validate_label[i]))
    s.sort()
    i = 0
    j = 0
    slen = len(s)
    tmp = 0
    while i < slen:
        while j < slen and s[i][0] == s[j][0]: j = j + 1
        for k in range(i, j):
            if s[k][1] == 1:
                correct += tmp
        for k in range(i, j):
            if s[k][1] == 0:
                tmp += 1
        i = j
    print(ttt, ' ', t, ' ', correct / total)
    toprint = str(ttt) + str(' ') + str(t) + str(' ') + str(correct / total) + str(' ') + str('\n')
    f.write(toprint)
    f.flush()
    data = get_test_value(test_data)
    predict = np.matmul(data, W)
    for i in range(0, predict.shape[0]):
        if predict[i] > 10:
            predict[i] = 10
    epredict = np.exp(predict)
    result = epredict / (1 + epredict)
    b = np.zeros(result.shape[0])
    result = np.c_[result, b]
    for i in range(0, result.shape[0]):
        result[i][1] = result[i][0]
        result[i][0] = i
    out = pandas.DataFrame(result, columns=['Id', 'label'])
    out['Id'] = out['Id'].astype(int)
    if config == '0':
        file = '../output/out' + str(ttt) + '_' + str(t) + '_' + str(correct / total) + '.csv'
    else:
        file = './huge/out' + str(t) + '_' + str(correct / total) + '.csv'
    out.to_csv(file, encoding='utf-8', index=False)


if __name__ == '__main__':
    config_file = open("config.txt", "r")
    config = config_file.read(1)
    config_file.close()
    f = open("log.txt", "w")
    if config == '0':
        train_data = pandas.read_csv('../train2.csv', header=None)
        train_label = pandas.read_csv('../label.csv')
        test_data = pandas.read_csv('../test2.csv', header=None)
    else:
        train_data = pandas.read_csv('train2.csv', header=None)
        train_label = pandas.read_csv('label.csv')
        test_data = pandas.read_csv('test2.csv', header=None)
    num_rows = train_data.shape[0]
    num_cols = train_data.shape[1] - 1
    train_num = int(num_rows * 0.8)
    train0 = []
    train1 = []
    validate0 = 0
    validate1 = 0
    for i in range(0, train_num):
        x = train_data.iloc[i]
        x = x[1:]
        if train_label.iloc[i,1] == 0:
            train0.append(x)
        else:
            train1.append(x)

    for i in range(train_num, num_rows):
        x = train_data.iloc[i]
        x = x[1:]
        if train_label.iloc[i,1] == 0:
            validate0 += 1
        else:
            validate1 += 1

    train_data_2, train_label_2 = get_validate_value(train_data, train_label, 0, train_num)
    validate_data, validate_label = get_validate_value(train_data, train_label, train_num, num_rows)
    W = np.random.uniform(-1.0, 1.0, [num_cols + 1, 1])

    totalalpha = 0
    alpha = []
    prob = []
    prob_sum = []
    for i in range(0, train_num):
        prob.append(1.0)
    calc_prob_sum(prob, prob_sum, train_num)
    W2 = np.zeros([num_cols + 1, 1])
    for ttt in range(0, 1000000): # Boost
        for t in range(0, 1000): # Single Training
            for xuexi in range(0, 30):
                data, label = get_train_value(train_data, train_label, train_num, prob_sum)
                d1 = np.zeros([num_cols + 1, 1])
                for i in range(0, BATCH_SIZE):
                    x = data[i].reshape([num_cols + 1, 1])
                    pp = p1(x, W.reshape([1, num_cols + 1]))
                    tt = (pp - label[i]) * x
                    d1 = d1 + tt
                W = W - learning_rate * d1
            predict_and_output(validate_data, validate_label, validate0, validate1, W, f, t, ttt)
        validate_predict = np.matmul(validate_data, W)
        correct = 0
        total = 0
        for i in range(0, validate_predict.shape[0]):
            if validate_predict[i] > 0.5 and validate_label[i] == 1: correct += 1
            if validate_predict[i] < 0.5 and validate_label[i] == 0: correct += 1
            total += 1
        eps = 1 - correct / total
        newalpha = 0.5 * np.log((1 - eps) / eps)
        newalpha = max(newalpha, -10)
        newalpha = min(newalpha, 10)
        alpha.append(newalpha)
        totalalpha += newalpha
        train_predict = np.matmul(train_data_2, W)
        for i in range(0, train_num):
            correct = 0
            if train_predict[i] > 0.5 and train_label_2[i] == 1: correct = 1
            if train_predict[i] < 0.5 and train_label_2[i] == 0: correct = 1
            if correct == 1:
                prob[i] = prob[i] * np.exp(-newalpha)
            else:
                prob[i] = prob[i] * np.exp(newalpha)
        W2 += newalpha * W
        calc_prob_sum(prob, prob_sum, train_num)
        predict_and_output(validate_data, validate_label, validate0, validate1, W2 / totalalpha, f, 99999999, ttt)
