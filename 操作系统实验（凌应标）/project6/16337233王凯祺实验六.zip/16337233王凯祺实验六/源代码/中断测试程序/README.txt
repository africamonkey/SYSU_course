testint.asm: NASM format, sector 26 (Offset 3200h)
