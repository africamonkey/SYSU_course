myos.asm: NASM format, sector 1 (Offset 0h)
