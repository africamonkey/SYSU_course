i34load.asm: NASM format, sector 27 (Offset 3400h)
i35load.asm: NASM format, sector 28 (Offset 3600h)
i36load.asm: NASM format, sector 29 (Offset 3800h)
i37load.asm: NASM format, sector 30 (Offset 3a00h)

