stone1.asm: NASM format, sector 20 (Offset 2600h)
stone2.asm: NASM format, sector 21 (Offset 2800h)
stone3.asm: NASM format, sector 22 (Offset 2a00h)
stone4.asm: NASM format, sector 23 (Offset 2c00h)

