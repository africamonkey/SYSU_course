forkload.asm: NASM format, sector 31 (Offset 3C00h)

