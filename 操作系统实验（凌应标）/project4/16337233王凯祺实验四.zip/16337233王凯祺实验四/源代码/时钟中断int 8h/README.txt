stone5.asm: NASM format, sector 16 (Offset 1e00h)
