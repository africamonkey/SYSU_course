loader.asm: MASM format, sector 2 (Offset 200h)
