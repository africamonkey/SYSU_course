i34load.asm: NASM format, sector 19 (Offset 2400h)
i35load.asm: NASM format, sector 20 (Offset 2600h)
i36load.asm: NASM format, sector 21 (Offset 2800h)
i37load.asm: NASM format, sector 22 (Offset 2a00h)

