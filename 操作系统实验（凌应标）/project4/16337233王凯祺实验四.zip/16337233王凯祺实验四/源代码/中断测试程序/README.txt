testint.asm: NASM format, sector 18 (Offset 2200h)
