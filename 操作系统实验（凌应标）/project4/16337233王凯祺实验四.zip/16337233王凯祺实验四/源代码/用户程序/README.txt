stone1.asm: NASM format, sector 12 (Offset 1600h)
stone2.asm: NASM format, sector 13 (Offset 1800h)
stone3.asm: NASM format, sector 14 (Offset 1a00h)
stone4.asm: NASM format, sector 15 (Offset 1c00h)

