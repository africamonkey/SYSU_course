syncload.asm: MASM format, sector 47 (Offset 5C00h)

