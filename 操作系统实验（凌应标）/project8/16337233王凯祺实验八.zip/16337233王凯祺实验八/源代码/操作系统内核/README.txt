loader.asm: MASM format, sector 3 (Offset 400h)
