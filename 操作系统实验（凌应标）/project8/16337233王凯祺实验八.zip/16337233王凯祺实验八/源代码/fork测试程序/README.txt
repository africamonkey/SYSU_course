forkload.asm: NASM format, sector 43 (Offset 5400h)

