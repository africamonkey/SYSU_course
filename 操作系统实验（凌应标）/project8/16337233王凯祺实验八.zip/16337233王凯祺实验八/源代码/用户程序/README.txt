stone1.asm: NASM format, sector 35 (Offset 4400h)
stone2.asm: NASM format, sector 37 (Offset 4800h)
stone3.asm: NASM format, sector 39 (Offset 4c00h)
stone4.asm: NASM format, sector 41 (Offset 5000h)

