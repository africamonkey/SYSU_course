package com.example.lab4;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.math.BigDecimal;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        operation = 0;
        screen_s = "0";
        last_s = "0";
        sign = "";
        setButtonClick();
    }

    private void setButtonClick() {
        text = (TextView)findViewById(R.id.textView);
        button1 = (Button)findViewById(R.id.button1);
        button2 = (Button)findViewById(R.id.button2);
        button3 = (Button)findViewById(R.id.button3);
        button4 = (Button)findViewById(R.id.button4);
        button5 = (Button)findViewById(R.id.button5);
        button6 = (Button)findViewById(R.id.button6);
        button7 = (Button)findViewById(R.id.button7);
        button8 = (Button)findViewById(R.id.button8);
        button9 = (Button)findViewById(R.id.button9);
        button10 = (Button)findViewById(R.id.button10);
        button11 = (Button)findViewById(R.id.button11);
        button12 = (Button)findViewById(R.id.button12);
        button13 = (Button)findViewById(R.id.button13);
        button14 = (Button)findViewById(R.id.button14);
        button15 = (Button)findViewById(R.id.button15);
        button16 = (Button)findViewById(R.id.button16);
        button17 = (Button)findViewById(R.id.button17);
        button18 = (Button)findViewById(R.id.button18);
        button19 = (Button)findViewById(R.id.button19);
        button20 = (Button)findViewById(R.id.button20);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                sign = "";
                screen_s = "0";
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                operation = 0;
                screen_s = "0";
                last_s = "0";
                sign = "";
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() > 0) {
                    if (screen_s.equals("0")) {
                        sign = "";
                    }
                    screen_s = screen_s.substring(0, screen_s.length() - 1);
                }

                if (screen_s.length() == 0) {
                    screen_s = "0";
                }
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                button20.callOnClick();
                last_s = sign + screen_s;
                text.setText(getString(R.string.display_result, sign, screen_s));
                screen_s = "0";
                sign = "";
                operation = 4;
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.equals("0")) screen_s = "";
                screen_s += '7';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.equals("0")) screen_s = "";
                screen_s += '8';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.equals("0")) screen_s = "";
                screen_s += '9';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                button20.callOnClick();
                last_s = sign + screen_s;
                text.setText(getString(R.string.display_result, sign, screen_s));
                screen_s = "0";
                sign = "";
                operation = 3;
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.equals("0")) screen_s = "";
                screen_s += '4';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.equals("0")) screen_s = "";
                screen_s += '5';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.equals("0")) screen_s = "";
                screen_s += '6';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                button20.callOnClick();
                last_s = sign + screen_s;
                text.setText(getString(R.string.display_result, sign, screen_s));
                screen_s = "0";
                sign = "";
                operation = 2;
            }
        });
        button13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.equals("0")) screen_s = "";
                screen_s += '1';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.equals("0")) screen_s = "";
                screen_s += '2';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.equals("0")) screen_s = "";
                screen_s += '3';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                button20.callOnClick();
                last_s = sign + screen_s;
                text.setText(getString(R.string.display_result, sign, screen_s));
                screen_s = "0";
                sign = "";
                operation = 1;
            }
        });
        button17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (sign.equals("")) sign = "-";
                else sign = "";
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.equals("0")) screen_s = "";
                screen_s += '0';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (screen_s.length() >= max_value_length) return;
                if (screen_s.charAt(screen_s.length() - 1) == '.') return;
                screen_s += '.';
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
        button20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (text.getText().equals("Error")) return;
                if (operation == 0) return;
                BigDecimal a = new BigDecimal(last_s);
                BigDecimal b = new BigDecimal(sign + screen_s);
                if (operation == 1) {
                    a = a.add(b);
                } else if (operation == 2) {
                    a = a.subtract(b);
                } else if (operation == 3) {
                    a = a.multiply(b);
                } else if (operation == 4) {
                    if (b.compareTo(BigDecimal.ZERO) == 0) {
                        text.setText("Error");
                        operation = 0;
                        return;
                    }
                    a = a.divide(b, 10, BigDecimal.ROUND_HALF_UP);
                }
                screen_s = a.stripTrailingZeros().toPlainString();
                sign = "";
                if (screen_s.charAt(0) == '-') {
                    sign = "-";
                    screen_s = screen_s.substring(1);
                }
                operation = 0;
                text.setText(getString(R.string.display_result, sign, screen_s));
            }
        });
    }

    private int operation;
    private String sign, screen_s, last_s;
    private TextView text;
    private Button button1, button2, button3, button4, button5, button6, button7, button8, button9, button10, button11, button12, button13, button14, button15, button16, button17, button18, button19, button20;
    private final int max_value_length = 100;
}
