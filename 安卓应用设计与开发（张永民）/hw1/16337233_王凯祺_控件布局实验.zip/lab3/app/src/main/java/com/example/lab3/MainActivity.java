package com.example.lab3;

import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindListener();
    }

    public void bindListener() {
        status = 0;
        mRecordTime = 0;
        mainChronometer = (Chronometer)findViewById(R.id.main);
        secondChronometer = (Chronometer)findViewById(R.id.second);
        startButton = (Button)findViewById(R.id.start);
        pauseButton = (Button)findViewById(R.id.pause);
        resetButton = (Button)findViewById(R.id.reset);
        pauseButton.setEnabled(false);

        startListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseButton.setEnabled(false);
                startButton.setEnabled(false);
                if (status == 0) {
                    mainChronometer.setBase(SystemClock.elapsedRealtime());
                    secondChronometer.setBase(SystemClock.elapsedRealtime());
                } else if (status == 1) {
                    mainChronometer.setBase(SystemClock.elapsedRealtime());
                    secondChronometer.setBase(secondChronometer.getBase() + (SystemClock.elapsedRealtime() - mRecordTime));
                }
                mainChronometer.start();
                secondChronometer.start();
                status = 2;
                pauseButton.setEnabled(true);
            }
        };
        startButton.setOnClickListener(startListener);

        pauseListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseButton.setEnabled(false);
                startButton.setEnabled(false);
                mainChronometer.stop();
                secondChronometer.stop();
                mainChronometer.setBase(SystemClock.elapsedRealtime());
                mRecordTime = SystemClock.elapsedRealtime();
                status = 1;
                startButton.setEnabled(true);
            }
        };
        pauseButton.setOnClickListener(pauseListener);

        resetListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseButton.setEnabled(false);
                startButton.setEnabled(false);
                mainChronometer.stop();
                secondChronometer.stop();
                mainChronometer.setBase(SystemClock.elapsedRealtime());
                secondChronometer.setBase(SystemClock.elapsedRealtime());
                status = 0;
                startButton.setEnabled(true);
            }
        };
        resetButton.setOnClickListener(resetListener);
    }

    private View.OnClickListener startListener;
    private Button startButton;
    private View.OnClickListener pauseListener;
    private Button pauseButton;
    private View.OnClickListener resetListener;
    private Button resetButton;
    private Chronometer mainChronometer;
    private Chronometer secondChronometer;
    private int status;
    private long mRecordTime;
}
