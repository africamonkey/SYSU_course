package com.example.lab2;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GridView gridview = (GridView)findViewById(R.id.grid_view);
        gridview.setAdapter(new ImageAdapter(this));
        bindListener();
        gridview.setOnItemClickListener(ocl_gridview);
        gridview.setOnItemLongClickListener(olcl_gridview);
    }

    public void bindListener() {
        ocl_gridview = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                Toast.makeText(MainActivity.this, "Short Click: " + Names[position], Toast.LENGTH_SHORT).show();
            }
        };
        olcl_gridview = new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(MainActivity.this, "Long Click: " + Names[position], Toast.LENGTH_SHORT).show();
                return true;
            }
        };
    }

    public class ImageAdapter extends BaseAdapter {
        private Context mContext;

        public ImageAdapter(Context c) {
            mContext = c;
        }

        public int getCount() {
            return mThumbIds.length;
        }

        public Object getItem(int position) {
            return null;
        }

        public long getItemId(int position) {
            return 0;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            View view = View.inflate(mContext, R.layout.gridview, null);
            RelativeLayout rl = (RelativeLayout)view.findViewById(R.id.grid_view);

            ImageView image = (ImageView)rl.findViewById(R.id.chooseImage);
            TextView name = (TextView)rl.findViewById(R.id.chooseName);
            TextView age = (TextView)rl.findViewById(R.id.chooseAge);

            image.setImageResource(mThumbIds[position]);
            name.setText(Names[position]);
            age.setText(String.valueOf(Ages[position]));

            return rl;
        }
    }
    private Integer[] mThumbIds = {
            R.drawable.a1,
            R.drawable.a2,
            R.drawable.a3,
            R.drawable.a4,
            R.drawable.a5,
            R.drawable.a6,
            R.drawable.a7
    };
    private String[] Names = {"陈伟霆", "迪丽热巴", "鹿晗",
            "王俊凯", "杨幂", "赵丽颖", "张艺兴"};
    private int[] Ages = {18, 21, 22, 32, 31, 18, 20, 25};
    private AdapterView.OnItemClickListener ocl_gridview;
    private AdapterView.OnItemLongClickListener olcl_gridview;
}
