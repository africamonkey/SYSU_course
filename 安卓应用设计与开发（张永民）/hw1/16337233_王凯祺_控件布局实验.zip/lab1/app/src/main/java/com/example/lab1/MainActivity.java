package com.example.lab1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Switch;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
    }

    private void initView() {
        btn = (Button)findViewById(R.id.register);
        btn.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String str = "";
                TextView t1 = (TextView)findViewById(R.id.textView);
                EditText e1 = (EditText)findViewById(R.id.username);
                str += t1.getText() + "：" + e1.getText() + "\n";

                TextView t2 = (TextView)findViewById(R.id.textView3);
                EditText e2 = (EditText)findViewById(R.id.password);
                str += t2.getText() + "：" + e2.getText() + "\n";

                TextView t3 = (TextView)findViewById(R.id.textView2);
                String hobby = "";
                CheckBox c1 = (CheckBox)findViewById(R.id.tiyu);
                if (c1.isChecked()) hobby += c1.getText();
                CheckBox c2 = (CheckBox)findViewById(R.id.yinyue);
                if (c2.isChecked()) hobby += c2.getText();
                CheckBox c3 = (CheckBox)findViewById(R.id.huihua);
                if (c3.isChecked()) hobby += c3.getText();
                if (hobby == "") hobby = "无";
                str += t3.getText() + "：" + hobby + "\n";

                TextView t4 = (TextView)findViewById(R.id.textView4);
                RadioButton r1 = (RadioButton)findViewById(R.id.dinianji);
                RadioButton r2 = (RadioButton)findViewById(R.id.gaonianji);
                str += t4.getText() + "：";
                if (r1.isChecked()) str += r1.getText();
                if (r2.isChecked()) str += r2.getText();
                str += "\n";

                TextView t5 = (TextView)findViewById(R.id.textView5);
                Spinner s1 = (Spinner)findViewById(R.id.xueyuan);
                str += t5.getText() + "：" + s1.getSelectedItem().toString() + "\n";

                TextView t6 = (TextView)findViewById(R.id.textView6);
                Switch s2 = (Switch)findViewById(R.id.quanrizhi);
                str += t6.getText() + "：";
                if (s2.isChecked()) str += "是"; else str += "否";

                Toast.makeText(getApplicationContext() ,str, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
