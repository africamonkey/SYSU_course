package com.example.grandwordremember;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class TestListViewAdapter extends BaseAdapter {
    private ArrayList<Problem> data;
    private Context context;
    private boolean display_answer;
    private SQLiteDatabase db;

    public TestListViewAdapter(Context context, SQLiteDatabase db) {
        super();
        this.context = context;
        data = new ArrayList<Problem>();
        display_answer = false;
        this.db = db;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (position < data.size()) {
            convertView = View.inflate(context, R.layout.list_item, null);
            ((TextView) convertView.findViewById(R.id.word)).setText(data.get(position).word);
            RadioGroup group = convertView.findViewById(R.id.radio_group);
            group.setTag(position);
            group.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    Problem tmp = data.get((int)group.getTag());
                    if (checkedId != -1) {
                        switch (checkedId) {
                            case R.id.radioButton_A:
                                tmp.selected = 0;
                                break;
                            case R.id.radioButton_B:
                                tmp.selected = 1;
                                break;
                            case R.id.radioButton_C:
                                tmp.selected = 2;
                                break;
                            case R.id.radioButton_D:
                                tmp.selected = 3;
                                break;
                        }
                    }
                    data.set((int)group.getTag(), tmp);
                }
            });
            switch (data.get(position).selected) {
                case 0:
                    group.check(R.id.radioButton_A);
                    break;
                case 1:
                    group.check(R.id.radioButton_B);
                    break;
                case 2:
                    group.check(R.id.radioButton_C);
                    break;
                case 3:
                    group.check(R.id.radioButton_D);
                    break;
            }
            if (display_answer) {
                switch (data.get(position).answer) {
                    case 0:
                        ((RadioButton) convertView.findViewById(R.id.radioButton_A)).setBackgroundResource(R.color.colorYellow);
                        break;
                    case 1:
                        ((RadioButton) convertView.findViewById(R.id.radioButton_B)).setBackgroundResource(R.color.colorYellow);
                        break;
                    case 2:
                        ((RadioButton) convertView.findViewById(R.id.radioButton_C)).setBackgroundResource(R.color.colorYellow);
                        break;
                    case 3:
                        ((RadioButton) convertView.findViewById(R.id.radioButton_D)).setBackgroundResource(R.color.colorYellow);
                        break;
                }
            }
            ((RadioButton) convertView.findViewById(R.id.radioButton_A)).setText(data.get(position).options[0]);
            ((RadioButton) convertView.findViewById(R.id.radioButton_B)).setText(data.get(position).options[1]);
            ((RadioButton) convertView.findViewById(R.id.radioButton_C)).setText(data.get(position).options[2]);
            ((RadioButton) convertView.findViewById(R.id.radioButton_D)).setText(data.get(position).options[3]);
        } else {
            convertView = View.inflate(context, R.layout.list_submit, null);
            Button btn = convertView.findViewById(R.id.submit);
            if (display_answer) btn.setVisibility(View.INVISIBLE);
            else btn.setVisibility(View.VISIBLE);
            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int i = 0; i < data.size(); ++i) {
                        Cursor c = db.query("words", new String[] {"test_count", "correct_count"}, "word = ?", new String[] {data.get(i).word}, null, null, null);
                        int test_count = 1, correct_count = data.get(i).selected == data.get(i).answer ? 1 : 0;
                        if (c != null && c.moveToNext()) {
                            test_count += c.getInt(0);
                            correct_count += c.getInt(1);
                        }
                        ContentValues cv = new ContentValues();
                        cv.put("word", data.get(i).word);
                        cv.put("level", data.get(i).level);
                        cv.put("test_count", test_count);
                        cv.put("correct_count", correct_count);
                        cv.put("last_test_time", "2019-01-01 12:00:00");
                        db.insert("words", null, cv);
                        db.update("words", cv, "word = ?", new String[] {data.get(i).word});
                    }
                    display_answer = true;
                    notifyDataSetChanged();
                }
            });
        }
        return convertView;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public Object getItem(int position) {
        if (position < data.size())
            return data.get(position);
        else
            return null;
    }

    @Override
    public int getCount() {
        if (data.size() == 0) return 0;
        return data.size() + 1;
    }

    public void addData(Problem p) {
        data.add(p);
    }

    public void clear() {
        data.clear();
    }
}
