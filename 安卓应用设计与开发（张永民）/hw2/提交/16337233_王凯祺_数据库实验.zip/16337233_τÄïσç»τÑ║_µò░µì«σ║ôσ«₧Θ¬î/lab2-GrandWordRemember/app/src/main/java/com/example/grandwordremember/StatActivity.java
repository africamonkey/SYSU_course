package com.example.grandwordremember;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TextView;

import java.io.File;

public class StatActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private ActionBar actionBar;
    private TableLayout tableLayout;
    private DBOpenHandler dbOpenHandler;
    private SQLiteDatabase db;

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent_home = new Intent(this,MainActivity.class);
                startActivity(intent_home);
                break;
            default:
                break;
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stat);

        //We have to tell the activity where the toolbar is
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        actionBar = getSupportActionBar();
        //Display home with the "up" arrow indicator
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        File file = new File(StatActivity.this.getFilesDir(), "words.db3");
        dbOpenHandler = new DBOpenHandler(StatActivity.this, file.getAbsolutePath(), null, 1);
        db = dbOpenHandler.getReadableDatabase();
        final String create_table_sql = "CREATE TABLE if not exists words(_id integer primary key autoincrement,word varchar(64) unique,level int default 0, test_count int default 0, correct_count int default 0,last_test_time timestamp)";
        db.execSQL(create_table_sql);

        tableLayout = (TableLayout)findViewById(R.id.tableLayout);
        Cursor c = db.query("words", new String[] {"word", "level", "test_count", "correct_count"}, "", new String[] {}, "", "", "word");
        while (c.moveToNext()) {
            View view = View.inflate(StatActivity.this, R.layout.stat_table_row, null);
            TextView t1 = (TextView)view.findViewById(R.id.content1);
            TextView t2 = (TextView)view.findViewById(R.id.content2);
            TextView t3 = (TextView)view.findViewById(R.id.content3);
            TextView t4 = (TextView)view.findViewById(R.id.content4);
            if (c.getString(0) != null) {
                t1.setText(c.getString(0));
                t2.setText(String.valueOf(c.getInt(1)));
                t3.setText(String.valueOf(c.getInt(2)));
                t4.setText(String.valueOf(c.getInt(3)));
                tableLayout.addView(view);
            }
        }
    }
}
