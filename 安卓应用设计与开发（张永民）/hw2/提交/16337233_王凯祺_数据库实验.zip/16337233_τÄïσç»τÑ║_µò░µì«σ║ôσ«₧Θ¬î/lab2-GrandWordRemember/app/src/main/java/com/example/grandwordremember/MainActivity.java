package com.example.grandwordremember;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private ActionBar actionBar;
    private AlertDialog alertDialog = null;
    private AlertDialog.Builder dialogBuilder = null;
    private ContentResolver resolver;
    private ContentValues cv;
    private final Uri uri = Uri.parse("content://com.africamonkey.granddict/");

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent_home = new Intent(this,MainActivity.class);
                startActivity(intent_home);
                break;
            case R.id.enterTest:
                Intent intent_test = new Intent(this,TestActivity.class);
                startActivity(intent_test);
                break;
            case R.id.addWord:
                ConstraintLayout addWordForm = (ConstraintLayout) getLayoutInflater()
                        .inflate(R.layout.add_word_dialog, null);
                dialogBuilder = new AlertDialog.Builder(MainActivity.this);
                alertDialog = dialogBuilder
                        .setTitle("添加单词")
                        .setView(addWordForm)
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        })
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String word = ((EditText)alertDialog.findViewById(R.id.editWord)).getText().toString();
                                String explanation = ((EditText)alertDialog.findViewById(R.id.editExplanation)).getText().toString();
                                String level = ((EditText)alertDialog.findViewById(R.id.editLevel)).getText().toString();
                                boolean overwrite = ((CheckBox)alertDialog.findViewById(R.id.checkOverwrite)).isChecked();
                                cv.clear();
                                cv.put("word", word);
                                cv.put("explanation", explanation);
                                cv.put("level", level);
                                cv.put("overwrite", overwrite);
                                Uri newUri = resolver.insert(uri, cv);  // null--错误
                                if (newUri == null) {
                                    Toast.makeText(MainActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(MainActivity.this, "Success", Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                        .create();
                alertDialog.show();
                break;
            case R.id.studyCount:
                Intent intent_stat = new Intent(this,StatActivity.class);
                startActivity(intent_stat);
                break;
            case R.id.findWord:
                break;
            case R.id.preference:
                break;
        }
        return true;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //We have to tell the activity where the toolbar is
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        actionBar = getSupportActionBar();
        //Display home with the "up" arrow indicator
        actionBar.setHomeButtonEnabled(false);
        //actionBar.setDisplayHomeAsUpEnabled(true);
        resolver = getContentResolver();
        cv = new ContentValues();
    }
}
