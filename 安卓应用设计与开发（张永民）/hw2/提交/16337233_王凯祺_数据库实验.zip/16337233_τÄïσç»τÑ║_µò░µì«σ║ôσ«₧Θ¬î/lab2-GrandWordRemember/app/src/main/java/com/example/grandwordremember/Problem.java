package com.example.grandwordremember;

public class Problem {
    public String word;
    public int level;
    public String[] options;
    public int answer;
    public int selected;
    Problem(String word, Integer level, String[] options, int answer) {
        this.word = word;
        this.level = level.intValue();
        this.options = options;
        this.answer = answer;
        this.selected = -1;
    }
}
