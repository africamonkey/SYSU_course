package com.example.grandwordremember;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class TestActivity extends AppCompatActivity {
    private Toolbar mToolbar;
    private ActionBar actionBar;
    private ContentResolver resolver;
    private final Uri uri = Uri.parse("content://com.africamonkey.granddict/");
    private int word_to_test;
    private ArrayList<String> word, explanation;
    private ArrayList<Integer> level;
    private TestListViewAdapter adapter;
    private ListView listView;
    private DBOpenHandler dbOpenHandler;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        resolver = getContentResolver();
        word_to_test = 10;

        //We have to tell the activity where the toolbar is
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        actionBar = getSupportActionBar();
        //Display home with the "up" arrow indicator
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        File file = new File(TestActivity.this.getFilesDir(), "words.db3");
        dbOpenHandler = new DBOpenHandler(TestActivity.this, file.getAbsolutePath(), null, 1);
        db = dbOpenHandler.getReadableDatabase();
        final String create_table_sql = "CREATE TABLE if not exists words(_id integer primary key autoincrement,word varchar(64) unique,level int default 0, test_count int default 0, correct_count int default 0,last_test_time timestamp)";
        db.execSQL(create_table_sql);

        adapter = new TestListViewAdapter(TestActivity.this, db);
        listView = (ListView)findViewById(R.id.testListView);
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent_home = new Intent(this,MainActivity.class);
                startActivity(intent_home);
                break;
            case R.id.startTest:
                Cursor local = db.query("words", new String[] {"max(word)"}, "", new String[] {}, "", "", "");
                String nowmax = "";
                if (local != null && local.moveToNext() && local.getString(0) != null) {
                    nowmax = local.getString(0);
                }
                Cursor c = resolver.query(uri, new String[] {"word", "explanation", "level"}, "word > ?", new String[] {nowmax}, "word limit " + String.valueOf(word_to_test));
                word = new ArrayList<String>();
                explanation = new ArrayList<String>();
                level = new ArrayList<Integer>();
                adapter.clear();
                while (c.moveToNext()) {
                    word.add(c.getString(0));
                    explanation.add(c.getString(1));
                    level.add(Integer.valueOf(c.getInt(2)));
                }
                int size = word.size();
                if (size < 10) {
                    Toast.makeText(this, "请添加至少10个单词，并在偏好设置中设置每次测试个数至少为10。", Toast.LENGTH_SHORT).show();
                    break;
                }
                for (int i = 0; i < size; ++i) {
                    int a1 = i, b1 = i, c1 = i, d1 = i, temp = -1;
                    int rnd = (int)(Math.random() * 4);
                    while (b1 == a1) b1 = (int)(Math.random() * size);
                    while (c1 == a1 || c1 == b1) c1 = (int)(Math.random() * size);
                    while (d1 == a1 || d1 == b1 || d1 == c1) d1 = (int)(Math.random() * size);
                    switch (rnd) {
                        case 0:
                            temp = 0;
                            break;
                        case 1:
                            temp = a1;
                            a1 = b1;
                            b1 = temp;
                            temp = 1;
                            break;
                        case 2:
                            temp = a1;
                            a1 = c1;
                            c1 = temp;
                            temp = 2;
                            break;
                        case 3:
                            temp = a1;
                            a1 = d1;
                            d1 = temp;
                            temp = 3;
                            break;
                        default:
                            temp = 0;
                            break;
                    }
                    adapter.addData(new Problem(word.get(i), level.get(i), new String[] {explanation.get(a1), explanation.get(b1), explanation.get(c1), explanation.get(d1)}, temp));
                }
                adapter.notifyDataSetChanged();
                break;
            default:
                break;
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_test, menu);
        return true;
    }
}
