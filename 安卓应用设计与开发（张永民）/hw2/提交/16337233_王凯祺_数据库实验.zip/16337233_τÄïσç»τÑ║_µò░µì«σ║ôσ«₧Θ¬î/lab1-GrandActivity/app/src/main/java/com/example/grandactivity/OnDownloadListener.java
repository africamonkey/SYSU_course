package com.example.grandactivity;

public interface OnDownloadListener {
    void onSuccess();
    void onFailed();
}
