package com.example.grandactivity;


import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.support.constraint.ConstraintLayout;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class WordListViewAdapter extends BaseAdapter {
    private Context context;
    private List<String> datas = new ArrayList<String>();
    private List<String> expls = new ArrayList<String>();
    private int show_explanation;
    private DBOpenHandler dbOpenHandler;
    private SQLiteDatabase db;
    private ContentValues cv;
    private AlertDialog alertDialog = null;
    private AlertDialog.Builder dialogBuilder = null;
    private boolean alwaysShowExplanation;

    public WordListViewAdapter(Context context, boolean alwaysShowExplanation) {
        super();
        this.context = context;
        show_explanation = -1;
        File file = new File(context.getFilesDir(), "dict.db3");
        dbOpenHandler = new DBOpenHandler(context, file.getAbsolutePath(), null, 1);
        db = dbOpenHandler.getReadableDatabase();
        final String create_table_sql = "CREATE TABLE IF NOT EXISTS dict(_id integer primary key autoincrement, word varchar(64) unique COLLATE NOCASE, explanation text, level int default 0, modified_time timestamp)";
        db.execSQL(create_table_sql);
        cv = new ContentValues();
        this.alwaysShowExplanation = alwaysShowExplanation;
    }

    /** 添加item数据 */
    public void addData(String text, String expl) {
        if (datas != null) {
            datas.add(text);
            expls.add(expl);
        }
    }


    public void clear() {
        datas.clear();
        expls.clear();
    }

    @Override
    public int getCount() {
        if (datas == null)
            return 0;
        return datas.size();
    }

    @Override
    public Object getItem(int position) {
        return datas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (position != show_explanation && alwaysShowExplanation == false) {
            convertView = View.inflate(context, R.layout.list_item, null);
            String text = datas.get(position);
            ((TextView) convertView.findViewById(R.id.title)).setText(text);
        } else {
            convertView = View.inflate(context, R.layout.list_item_with_explanation, null);
            String word = datas.get(position);
            String expl = expls.get(position);
            ((TextView) convertView.findViewById(R.id.title)).setText(word);
            ((TextView) convertView.findViewById(R.id.explanation)).setText(expl);
        }
        convertView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (show_explanation == position) {
                    show_explanation = -1;
                } else {
                    show_explanation = position;
                }
                notifyDataSetChanged();
            }
        });
        convertView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(final View v) {
                PopupMenu popup = new PopupMenu(context, v.findViewById(R.id.title));
                popup.getMenuInflater().inflate(R.menu.menu_pop, popup.getMenu());
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.delete:
                                db.delete("dict", "word=?", new String[] {datas.get(position)});
                                datas.remove(position);
                                expls.remove(position);
                                notifyDataSetChanged();
                                break;
                            case R.id.modify:
                                ConstraintLayout modifyWordForm = (ConstraintLayout) LayoutInflater.from(context)
                                        .inflate(R.layout.modify_word_dialog, null);
                                dialogBuilder = new AlertDialog.Builder(context);
                                alertDialog = dialogBuilder
                                        .setTitle("添加单词")
                                        .setView(modifyWordForm)
                                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                            }
                                        })
                                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                String explanation = ((EditText)alertDialog.findViewById(R.id.editExplanation)).getText().toString();
                                                String level = ((EditText)alertDialog.findViewById(R.id.editLevel)).getText().toString();
                                                cv.clear();
                                                cv.put("explanation", explanation);
                                                cv.put("level", level);
                                                db.update("dict", cv, "word=?", new String[] {datas.get(position)});
                                                expls.set(position, explanation);
                                                notifyDataSetChanged();
                                            }
                                        })
                                        .create();
                                alertDialog.show();
                                break;
                        }
                        return true;
                    }
                });
                popup.show();
                return true;
            }
        });
        return convertView;
    }

}
