package com.example.grandactivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.util.Pair;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.File;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ProgressDialog mProgressDialog;
    private Toolbar mToolbar;
    private ActionBar actionBar;
    private DBOpenHandler dbOpenHandler;
    private SQLiteDatabase db;
    private final String dictURL = "http://172.18.187.9:8080/dict/";
    private final String dictURL_bak = "http://test.wronganswer.cn:8090/dict.json";
    private OnDownloadListener downListener;
    String localdict;
    private AlertDialog alertDialog = null;
    private AlertDialog.Builder dialogBuilder = null;
    private ContentValues cv;
    private boolean alwaysShowExplanation;
    private LinearLayout linearLayout;
    private int nowABCDEFG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // top ABCDEFG
        nowABCDEFG = -1;
        linearLayout = (LinearLayout)findViewById(R.id.linearLayout);
        for (int i = 0; i < 26; ++i) {
            TextView textView = new TextView(this);
            textView.setText(String.valueOf((char)('A' + i)));
            textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            textView.setPadding(i == 0 ? 20 : 10, 5, i == 25 ? 20 : 10, 5);
            textView.setTextColor(Color.BLACK);
            textView.setId(100000 + i);
            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    TextView textView = (TextView)v.findViewById(v.getId());
                    for (int j = 0; j < 26; ++j) {
                        TextView t = (TextView)findViewById(100000 + j);
                        t.setTextColor(Color.BLACK);
                    }
                    if (nowABCDEFG == textView.getId()) {
                        new ImportTask(MainActivity.this, db, alwaysShowExplanation).execute();
                    } else {
                        nowABCDEFG = textView.getId();
                        textView.setTextColor(Color.parseColor("#F44336"));
                        new SearchABCDEFGTask(MainActivity.this, db, alwaysShowExplanation, String.valueOf((char)('a' + (nowABCDEFG - 100000)))).execute();
                    }
                }
            });
            linearLayout.addView(textView);
        }

        //We have to tell the activity where the toolbar is
        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        actionBar = getSupportActionBar();
        //Display home with the "up" arrow indicator
        actionBar.setHomeButtonEnabled(false);
        //actionBar.setDisplayHomeAsUpEnabled(true);
        File file = new File(this.getFilesDir(), "dict.db3");
        Log.d("DATABASE", "sql file = " + file.getAbsolutePath());
        dbOpenHandler = new DBOpenHandler(this.getApplicationContext(), file.getAbsolutePath(), null, 1);
        db = dbOpenHandler.getReadableDatabase();
        final String create_table_sql = "CREATE TABLE IF NOT EXISTS dict(_id integer primary key autoincrement, word varchar(64) unique COLLATE NOCASE, explanation text, level int default 0, modified_time timestamp)";
        db.execSQL(create_table_sql);
        cv = new ContentValues();
        alwaysShowExplanation = false;
        new ImportTask(MainActivity.this, db, alwaysShowExplanation).execute();
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.findItem(R.id.app_bar_switch).setChecked(alwaysShowExplanation);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(this,MainActivity.class);
                startActivity(intent);
                break;
            case R.id.app_bar_add:
                ConstraintLayout addWordForm = (ConstraintLayout) getLayoutInflater()
                        .inflate(R.layout.add_word_dialog, null);
                dialogBuilder = new AlertDialog.Builder(MainActivity.this);
                alertDialog = dialogBuilder
                        .setTitle("添加单词")
                        .setView(addWordForm)
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        })
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String word = ((EditText)alertDialog.findViewById(R.id.editWord)).getText().toString();
                                String explanation = ((EditText)alertDialog.findViewById(R.id.editExplanation)).getText().toString();
                                String level = ((EditText)alertDialog.findViewById(R.id.editLevel)).getText().toString();
                                boolean overwrite = ((CheckBox)alertDialog.findViewById(R.id.checkOverwrite)).isChecked();
                                cv.clear();
                                cv.put("word", word);
                                cv.put("explanation", explanation);
                                cv.put("level", level);
                                db.insert("dict", null, cv);
                                if (overwrite) {
                                    db.update("dict", cv, "word=?", new String[]{word});
                                }
                                new ImportTask(MainActivity.this, db, alwaysShowExplanation).execute();
                            }
                        })
                        .create();
                alertDialog.show();
                break;
            case R.id.app_bar_search:
                return super.onOptionsItemSelected(item);
            case R.id.app_bar_download:
                File file = new File(this.getCacheDir(), "dict.json");
                localdict = file.getAbsolutePath();
                // instantiate it within the onCreate method
                mProgressDialog = new ProgressDialog(MainActivity.this);
                mProgressDialog.setMessage("正在下载和导入单词");
                mProgressDialog.setIndeterminate(true);
                mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                mProgressDialog.setCancelable(true);
                // execute this when the downloader must be fired
                downListener = new OnDownloadListener() {
                    @Override
                    public void onSuccess() {
                        new ImportTask(MainActivity.this, db, alwaysShowExplanation).execute();
                    }

                    @Override
                    public void onFailed() {
                    }
                };
                final DownloadTask downloadTask = new DownloadTask(MainActivity.this, db, mProgressDialog, downListener);
                mProgressDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        downloadTask.cancel(true);
                    }
                });
                downloadTask.execute(dictURL_bak, localdict);
                break;
            case R.id.app_bar_switch:
                alwaysShowExplanation = !alwaysShowExplanation;
                new ImportTask(MainActivity.this, db, alwaysShowExplanation).execute();
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem searchItem = menu.findItem(R.id.app_bar_search);
        SearchView searchView = null;
        if (searchItem != null) {
            searchView = (SearchView)searchItem.getActionView();
        }
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                new SearchTask(MainActivity.this, db, alwaysShowExplanation, query).execute();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                new ImportTask(MainActivity.this, db, alwaysShowExplanation).execute();
                return false;
            }
        });
        return true;
    }
}
