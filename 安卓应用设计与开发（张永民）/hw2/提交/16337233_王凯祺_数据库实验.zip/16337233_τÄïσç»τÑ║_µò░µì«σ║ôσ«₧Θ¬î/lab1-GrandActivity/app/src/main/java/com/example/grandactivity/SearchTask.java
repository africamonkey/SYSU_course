package com.example.grandactivity;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.PowerManager;
import android.view.View;
import android.widget.ListView;
import android.widget.ProgressBar;

import java.util.ArrayList;

public class SearchTask extends AsyncTask<Void, Integer, Void> {
    // Usage: DownloadTask.execute(String URL, String downloadLocation);

    private Context context;
    private PowerManager.WakeLock mWakeLock;
    private SQLiteDatabase db;
    private ProgressBar mProgressBar;
    private ListView listView;
    private WordListViewAdapter adapter;
    private ArrayList<String> words = new ArrayList<String>();
    private ArrayList<String> expls = new ArrayList<String>();
    private boolean alwaysShowExplanation;
    private String queryWord;

    public SearchTask(Context context, SQLiteDatabase db, boolean alwaysShowExplanation, String queryWord) {
        this.context = context;
        this.db = db;
        this.mProgressBar = ((Activity)context).findViewById(R.id.progressBar);
        this.mProgressBar.setVisibility(View.VISIBLE);
        listView = ((Activity)context).findViewById(R.id.listWords);
        this.adapter = new WordListViewAdapter(context, alwaysShowExplanation);
        listView.setAdapter(adapter);
        this.alwaysShowExplanation = alwaysShowExplanation;
        this.queryWord = queryWord;
    }

    @Override
    protected Void doInBackground(Void... sUrl) {
        String table = "dict";
        String[] columns = new String[] {"word", "explanation"};
        String selection = "word like ?";
        String[] selectionArgs = new String[] {"%" + queryWord + "%"};
        String groupBy = "";
        String having = "";
        String orderBy = "word";
        Cursor cursor = db.query(table, columns, selection, selectionArgs, groupBy, having, orderBy);
        int total = cursor.getCount();
        int i = 0;
        words.clear();
        expls.clear();
        while (cursor.moveToNext()) {
            String word = cursor.getString(0);
            String expl = cursor.getString(1);
            ++ i;
            publishProgress((int) (i * 100 / total));
            words.add(word);
            expls.add(expl);
        }
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        // take CPU lock to prevent CPU from going off if the user
        // presses the power button during download
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,
                getClass().getName());
        mWakeLock.acquire();
    }

    @Override
    protected void onProgressUpdate(Integer... progress) {
        super.onProgressUpdate(progress);
        // if we get here, length is known, now set indeterminate to false
        mProgressBar.setIndeterminate(false);
        mProgressBar.setMax(100);
        mProgressBar.setProgress(progress[0]);
    }

    @Override
    protected void onPostExecute(Void result) {
        mWakeLock.release();
        mProgressBar.setVisibility(View.GONE);
        adapter.clear();
        adapter.notifyDataSetChanged();
        for (int i = 0; i < words.size(); ++i) {
            adapter.addData(words.get(i), expls.get(i));
            adapter.notifyDataSetChanged();
        }
    }

    @Override
    protected void finalize() throws Throwable {
        context = null;
        mProgressBar = null;
        super.finalize();
    }
}
