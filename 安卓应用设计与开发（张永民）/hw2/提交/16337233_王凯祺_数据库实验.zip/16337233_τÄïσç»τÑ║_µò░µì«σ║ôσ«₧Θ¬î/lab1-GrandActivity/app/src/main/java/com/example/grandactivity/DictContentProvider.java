package com.example.grandactivity;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

import java.io.File;

public class DictContentProvider extends ContentProvider {

    private DBOpenHandler dbOpenHandler;
    private SQLiteDatabase db;

    public DictContentProvider() {
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        // Implement this to handle requests to delete one or more rows.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public String getType(Uri uri) {
        // TODO: Implement this to handle requests for the MIME type of the data
        // at the given URI.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        // TODO: Implement this to handle requests to insert a new row.
        String word = (String)values.get("word");
        String explanation = (String)values.get("explanation");
        String level = (String)values.get("level");
        boolean overwrite = (boolean)values.get("overwrite");
        ContentValues cv = new ContentValues();
        cv.put("word", word);
        cv.put("explanation", explanation);
        cv.put("level", level);
        cv.put("modified_time", "2019-01-01 00:00:00");
        db.insert("dict", null, cv);
        if (overwrite) {
            db.update("dict", cv, "word=?", new String[]{word});
        }
        return uri;
    }

    @Override
    public boolean onCreate() {
        File file = new File(getContext().getFilesDir(), "dict.db3");
        dbOpenHandler = new DBOpenHandler(getContext(), file.getAbsolutePath(), null, 1);
        db = dbOpenHandler.getReadableDatabase();
        final String create_table_sql = "CREATE TABLE IF NOT EXISTS dict(_id integer primary key autoincrement, word varchar(64) unique COLLATE NOCASE, explanation text, level int default 0, modified_time timestamp)";
        db.execSQL(create_table_sql);
        return true;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        String table = "dict";
        String groupBy = "";
        String having = "";
        Cursor cursor = db.query(table, projection, selection, selectionArgs, groupBy, having, sortOrder);
        return cursor;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        // TODO: Implement this to handle requests to update one or more rows.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}
