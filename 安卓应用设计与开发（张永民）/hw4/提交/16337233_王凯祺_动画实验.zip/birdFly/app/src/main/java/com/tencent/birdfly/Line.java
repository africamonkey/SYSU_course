package com.tencent.birdfly;

public class Line {
    Line(float sX, float sY, float eX, float eY) {
        this.sX = sX;
        this.sY = sY;
        this.eX = eX;
        this.eY = eY;
    }
    public float startX() {
        return sX;
    }
    public float startY() {
        return sY;
    }
    public float endX() {
        return eX;
    }
    public float endY() {
        return eY;
    }
    private float sX, sY, eX, eY;
}
