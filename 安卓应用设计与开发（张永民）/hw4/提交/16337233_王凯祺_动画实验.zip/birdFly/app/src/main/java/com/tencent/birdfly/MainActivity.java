package com.tencent.birdfly;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.graphics.Path;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Line> pos;
    private boolean isRecording;
    private AnimationDrawable recordingDrawable;
    ImageView bird, bird2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        bird = findViewById(R.id.bird);
        AnimationDrawable birdDrawable = (AnimationDrawable)bird.getBackground();
        birdDrawable.start();

        bird2 = findViewById(R.id.bird2);
        AnimationDrawable bird2Drawable = (AnimationDrawable)bird2.getBackground();
        bird2Drawable.start();

        ImageView recording = findViewById(R.id.recording);
        recordingDrawable = (AnimationDrawable)recording.getBackground();

        pos = new ArrayList<>();
        isRecording = false;

        bird.setVisibility(View.VISIBLE);
        bird2.setVisibility(View.INVISIBLE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case R.id.start_video:
                pos.clear();
                isRecording = true;
                recordingDrawable.start();
                break;
            case R.id.stop_video:
                isRecording = false;
                recordingDrawable.stop();
                break;
            case R.id.start_replay:
                bird.setVisibility(View.INVISIBLE);
                bird2.setVisibility(View.VISIBLE);
                int size = size_pos();
                AnimatorSet animatorSet = new AnimatorSet();
                List<Animator> animatorList = new ArrayList<Animator>();
                bird2.setX(get_pos(0).startX());
                bird2.setY(get_pos(0).startY());
                for (int i = 0; i < size; ++i) {
                    Path path = new Path();
                    path.moveTo(get_pos(i).startX(), get_pos(i).startY());
                    path.lineTo(get_pos(i).endX(), get_pos(i).endY());
                    float goX = get_pos(i).endX() - get_pos(i).startX();
                    float goY = get_pos(i).endY() - get_pos(i).startY();
                    Path path2 = new Path();
                    if (goX >= 0) {
                        path2.moveTo(1.0f, 1.0f);
                    } else {
                        path2.moveTo(-1.0f, 1.0f);
                    }
                    double dis = Math.sqrt(goX * goX + goY * goY);
                    WindowManager manager = getWindowManager();
                    DisplayMetrics outMetrics = new DisplayMetrics();
                    manager.getDefaultDisplay().getMetrics(outMetrics);
                    int width = outMetrics.widthPixels;
                    int height = outMetrics.heightPixels;
                    double disAll = Math.sqrt(1.0 * width * width + 1.0 * height * height);
                    int secs = (int)Math.floor(dis / disAll * 5000);
                    ObjectAnimator dirAnimator = ObjectAnimator.ofFloat(bird2, "scaleX", "scaleY", path2);
                    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(bird2, "translationX","translationY", path);
                    objectAnimator.setDuration(secs);
                    objectAnimator.setRepeatCount(0);
                    objectAnimator.setInterpolator(new LinearInterpolator());
                    animatorList.add(dirAnimator);
                    animatorList.add(objectAnimator);
                }
                animatorSet.playSequentially(animatorList);
                animatorSet.start();

                break;
            case R.id.stop_replay:
                bird.setVisibility(View.VISIBLE);
                bird2.setVisibility(View.INVISIBLE);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    public void push_pos(float startX, float startY, float endX, float endY) {
        pos.add(new Line(startX, startY, endX, endY));
    }

    public int size_pos() {
        return pos.size();
    }

    public Line get_pos(int index) {
        return pos.get(index);
    }
}
