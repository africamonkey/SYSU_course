package com.tencent.birdfly;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.Toast;

public class ClickView extends View {

    public ClickView(Context context) {
        super(context);
        animationStarted = false;
    }

    public ClickView(Context context, AttributeSet attrs) {
        super(context, attrs);
        animationStarted = false;
    }

    public ClickView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        animationStarted = false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (animationStarted) break;
                Log.d("A", String.valueOf(event.getX()) + " " + String.valueOf(event.getY()));
                final ImageView bird = ((Activity)getContext()).findViewById(R.id.bird);
                final float birdX = bird.getX() + ((float)bird.getWidth() / 2);
                final float birdY = bird.getY() + ((float)bird.getHeight() / 2);
                final float goX = event.getX() - birdX;
                final float goY = event.getY() - birdY;
                ((MainActivity)getContext()).push_pos(bird.getX(), bird.getY(),
                        event.getX() - ((float)bird.getWidth() / 2), event.getY() - ((float)bird.getHeight() / 2));
                final double dis = Math.sqrt(goX * goX + goY * goY);
                WindowManager manager = ((Activity)getContext()).getWindowManager();
                DisplayMetrics outMetrics = new DisplayMetrics();
                manager.getDefaultDisplay().getMetrics(outMetrics);
                int width = outMetrics.widthPixels;
                int height = outMetrics.heightPixels;
                final double disAll = Math.sqrt(1.0 * width * width + 1.0 * height * height);
                final int secs = (int)Math.floor(dis / disAll * 5000);
                if (goX >= 0) {
                    bird.setScaleX(1.0f);
                } else {
                    bird.setScaleX(-1.0f);
                }
                TranslateAnimation anim = new TranslateAnimation(Animation.RELATIVE_TO_SELF, 0.0f,
                        Animation.ABSOLUTE, goX,
                        Animation.RELATIVE_TO_SELF, 0.0f,
                        Animation.ABSOLUTE, goY);
                anim.setFillBefore(true);
                anim.setFillAfter(true);
                anim.setStartOffset(0);
                anim.setDuration(secs);
                anim.setRepeatMode(Animation.ABSOLUTE);
                anim.setRepeatCount(0);
                anim.setInterpolator(new LinearInterpolator());
                anim.setAnimationListener(new Animation.AnimationListener() {
                    @Override
                    public void onAnimationStart(Animation animation) {
                        animationStarted = true;
                    }

                    @Override
                    public void onAnimationEnd(Animation animation) {
                        bird.clearAnimation();
                        bird.setX(bird.getX() + goX);
                        bird.setY(bird.getY() + goY);
                        animationStarted = false;
                    }

                    @Override
                    public void onAnimationRepeat(Animation animation) {

                    }
                });
                bird.startAnimation(anim);
                break;
        }
        return true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }
    private boolean animationStarted;
}
