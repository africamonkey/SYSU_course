package com.y123456.yiheng;

public class Info {
    private int id;
    private String name;
    private String birthday;

    public Info(int id, String name, String birthday) {
        this.id = id;
        this.name = name;
        this.birthday = birthday;
    }
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getBirthday() {
        return birthday;
    }
}
