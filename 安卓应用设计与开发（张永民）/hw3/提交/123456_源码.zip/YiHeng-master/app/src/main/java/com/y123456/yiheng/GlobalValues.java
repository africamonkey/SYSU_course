package com.y123456.yiheng;

//这个类主要用来存放全局变量 by suzh

public class GlobalValues {
    // 生日提醒闹钟
    public final static String BIRTHDAT_REMIND = "com.y123456.Yiheng.BIRTHDAT_REMIND";
    // 定时闹钟
    public final static String SPECIAL_DATE_REMIND = "com.y123456.Yiheng.SPECIAL_DATE_REMIND";
}