package com.y123456.yiheng;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;
import java.util.Map;

/**
 * Created on 2019/2/18 11:44
 */

public class CalllogAdapter extends BaseAdapter {
    private Context context;
    private List<Map<String, String>> list;

    public CalllogAdapter(Context context, List<Map<String, String>> list) {
        this.context = context;
        this.list = list;
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    private Holder holder;

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_calllog, parent, false);
            holder = new Holder();
            holder.tvName = (TextView) convertView.findViewById(R.id.tv_item_name);
            holder.tvDuration = (TextView)convertView.findViewById(R.id.tv_item_duration);
            holder.tvTimeLead = (TextView)convertView.findViewById(R.id.tv_item_time_lead);
            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }
        /**
         * 通话类型 此处可以根据类型进行逻辑处理，本demo忽略处理
         */
        holder.tvDuration.setText(list.get(position).get("duration"));
        /* 通话记录的联系人
         */
        if (TextUtils.equals((list.get(position).get("name") + ""), "未备注联系人")) {// 通话记录的联系人
            holder.tvName.setText(list.get(position).get("number"));// 通话记录的联系人
        } else {
            holder.tvName.setText(list.get(position).get("name") + "(" + list.get(position).get("number") + ")");// 通话记录的联系人
        }
        holder.tvTimeLead.setText(list.get(position).get("day") + "  " + list.get(position).get("time"));// 通话距离
        return convertView;
    }

    class Holder {
        private TextView tvName,//名字
                tvDuration,//时长
                tvTimeLead;//时间差
    }
}

