<?php
require_once('./include/database_config.php');
$view_title = "登录";
require("./template/login_page.php");
?>