<?php
require_once("./include/database_config.php");
$view_title = "注册";
require("template/register_page.php");
?>
