<?php
require_once('./include/database_config.php');
$view_title = "图书管理系统";
require('./template/index.php');
?>